//#include "index.h"  //Web page header file
const char MAIN_page[] PROGMEM = R"=====(
<!DOCTYPE html><html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<h1>Waage</h1>
<p>TARE <a href="/tare"><button>TARE</button></a></p>  
<p>PRESSURE: <span id="PRESSURE">0</span><a href="/pressure"><button class="button">PRESSURE</button></a></p>  
<p>CALIBRATE <a href="/calibrate"><button>CALIBRATE</button></a></p>  
<script>
setInterval(function() {
  getData();
}, 2000); // Call a function repeatively with 2000 mSeconds interval
 
function getData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("PRESSURE").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", "readWaage", true);
  xhttp.send();
}
</script>
</body>
</html>
)=====";
